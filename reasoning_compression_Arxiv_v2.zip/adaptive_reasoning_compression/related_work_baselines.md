# Reasoning-Compression Baselines: Methods & Reported Results

Reference notes for CRISP's related-work / survey section. For each cited compression
method we record (1) what the method does and (2) the numbers it reports **only on
benchmarks that overlap with CRISP's evaluation grid**.

**CRISP evaluation grid**
- Benchmarks: MATH-500, AIME 2024, AIME 2025, GPQA-Diamond, MMLU
- Base models: Qwen3-8B, Qwen3-14B, DeepSeek-R1-Distill-Llama-8B

**Note on OPSD (arXiv:2601.18734):** this is *our own* prior work (renamed), **not** a
third-party baseline, so it is excluded from the comparison below.

---

## Coverage matrix (overlap with CRISP benchmarks)

Legend: ✓ = evaluated on that benchmark; ~ = related-but-not-identical split (see notes);
"model overlap" = shares a CRISP base model.

| Method | arXiv | MATH-500 | AIME24 | AIME25 | GPQA-D | MMLU | Model overlap |
|---|---|:--:|:--:|:--:|:--:|:--:|---|
| **RL length-penalty** |||||||
| L1 / LCPO | 2503.04697 | ~ (full MATH) | ✓ | ✓ | ~ (figs only) | ~ (figs only) | none (DeepScaleR-1.5B) |
| ThinkPrune | 2504.01296 | ✓ | ✓ | – | – | – | none (1.5B, QwQ-32B) |
| DLER | 2510.15110 | ~ (full MATH) | ✓ | – | – | – | none (1.5B/7B, Nemotron-8B) |
| DIET | 2505.19217 | ✓ | ✓ | – | – | – | none (R1-Distill-Qwen-1.5B) |
| DiPO | 2601.21418 | ✓ | – | ✓ | ~ ("GPQA") | ✓ | ~ (R1-0528-Qwen3-8B) |
| Leash | 2512.21540 | – | ✓ | ✓ | ~ ("GPQA") | ~ (MMLU-Pro) | none (1.5B, Qwen3-4B) |
| AdaptThink | 2505.13417 | ✓ | ✓ | – | – | ✓ (OOD) | none (1.5B/7B) |
| TRAAC | 2510.01581 | – | ~ (22+23+24) | – | ✓ | – | none (Qwen3-4B, R1-Qwen-7B) |
| **SFT CoT-compression** |||||||
| SEER | 2509.14093 | – | – | – | – | – | none (code/SE domain) |
| TokenSkip | 2502.12067 | ✓ | – | – | – | – | none (Llama-3.1-8B, Qwen2.5) |
| DAP / LiteCoT | 2505.19716 | ✓ | ✓ | ✓ | ✓ | ~ (MMLU-STEM) | none (Qwen2.5-Math) |
| S3-CoT | 2602.01982 | ~ (full MATH) | ✓ | – | – | – | none (Qwen2.5-7B, R1-7B) |
| V-Skip | 2601.13879 | – | – | – | – | – | none (multimodal VLM) |
| CtrlCoT | 2601.20467 | ✓ | – | – | – | – | none (Qwen2.5-Instruct) |
| **Training-free / inference-time** |||||||
| Chain of Draft | 2502.18600 | – | – | – | – | – | none (GPT-4o, Claude 3.5) |
| TrimR | 2505.17155 | ✓ | ✓ | ✓ | ✓ | – | none (32–38B) |
| **NoWait** | 2506.08343 | – | ✓ | ✓ | ✓ | – | **✓ Qwen3-8B, Qwen3-14B** |
| FlowSteer | 2602.05539 | ✓ | ✓ | – | – | – | none (1.5B/7B, QwQ-32B) |
| **On-policy self-distillation (non-OPSD relatives)** |||||||
| SDFT | 2601.19897 | – | – | – | – | ~ (retention probe) | none (Qwen2.5-7B, Olmo-3) |
| SDPO | 2601.20802 | – | – | – | – | ~ (MMLU-Pro holdout) | ~ (Qwen3-8B, other tasks) |
| OPCD | 2602.12275 | – | – | – | – | – | ~ (Qwen3-8B, other tasks) |

**Two structural caveats for any comparison table:**
1. **NoWait is the only method sharing CRISP's exact base models** (Qwen3-8B/14B) *and*
   overlapping benchmarks — the sole true head-to-head row. Everything else is
   method-level (cross-model), needing a footnote.
2. **No cited compression method uses DeepSeek-R1-Distill-Llama-8B**, and **none reports
   plain MMLU as a target task** (only DiPO reports MMLU, on Qwen3-4B; SDFT/SDPO touch
   MMLU/MMLU-Pro only as retention/holdout probes). Several "GPQA" cites are not the
   Diamond split, and several "MATH" numbers are full-MATH, not MATH-500 — flagged inline.

---

## RL length-penalty methods

### L1 / LCPO — arXiv:2503.04697 (Aggarwal & Welleck, 2025)
**Method.** *Length-Controlled Policy Optimization.* RL (GRPO-style) with a reward that
penalizes deviation from a user-requested token budget, so the model learns to hit a
target length on command. Two variants: L1-Exact (hit the budget) and L1-Max (stay under
it). Requires ground-truth answers.
**Base model.** DeepScaleR-1.5B-Preview (RL-tuned R1-Distill-Qwen-1.5B); a 7B scaling run
uses R1-Distill-7B. *No CRISP model overlap.*
**Results (overlap only).** Reports accuracy *at requested budgets* {512,1024,2048,3600},
not a before/after compression %.
- MATH (full set, not MATH-500): L1-Max 70.8% @ 299 tok; 78.3% @ 541 tok; 79.4% @ 631 tok
  (Qwen-1.5B base 73.4% @ 554 tok).
- AIME24 / AIME25 (Table 3): L1-Exact 24.8 / 22.5; L1-Max 27.3 / 21.5 (base 29.2 / 21.7).
- GPQA & MMLU: figures only (Fig 3 / Fig 9) — **no citable numeric values**.

### ThinkPrune — arXiv:2504.01296 (Hou et al., 2025)
**Method.** Iterative RL pruning of long chains-of-thought under a shrinking token-budget
constraint (4k→3k→2k), keeping correctness reward. Requires ground-truth answers.
**Base models.** R1-Distill-Qwen-1.5B, DeepScaleR-1.5B, QwQ-32B. *No CRISP model overlap.*
**Results (baseline → ThinkPrune final; acc / avg tokens):**
- MATH-500: R1-1.5B 82.9→83.2, 5560→1938 tok (~65% ↓); DeepScaleR 88.5→86.9, 3084→1881
  (~39% ↓); QwQ-32B 95.1→93.8, 4289→2162 (~50% ↓).
- AIME24: R1-1.5B 29.4→27.1, 15484→5631 (~64% ↓); DeepScaleR 40.3→36.5, 9463→5301 (~44% ↓);
  QwQ-32B 78.8→72.5, 13822→7631 (~45% ↓).
- AIME25 / GPQA-D / MMLU: not evaluated.

### DLER — arXiv:2510.15110 (Liu et al., 2025, NVIDIA)
**Method.** "Doing Length penalty right": RL with a truncation-aware length penalty plus
curriculum, maximizing "intelligence per token." DA-DLER adds difficulty-adaptive targets.
Requires ground-truth answers.
**Base models.** R1-Distill-Qwen-1.5B/7B, Llama-3.1-Nemotron-Nano-8B. *No CRISP overlap.*
**Results (overlap = AIME24 only; acc / tokens):**
- R1-1.5B: 29.79 → DLER 34.38 (3551 tok) / DA-DLER 34.37 (2888 tok); base length 16916.
- R1-7B: 55.40 → DLER 55.62 (3230) / DA-DLER 53.90 (2878); base length 13241.
- Nemotron-8B: 66.40 → DLER 63.54 (3867) / Merge 66.66 (5013); base length 9899.
- Headline overall length cut (avg over 5 benchmarks): 1.5B −77–80%, 7B −69–73%, 8B −55%.
- Uses full MATH (not MATH-500); no AIME25 / GPQA-D / MMLU.

### DIET — arXiv:2505.19217 (Chen et al., 2025)
**Method.** "The overthinker's diet": difficulty-aware RL that sets per-problem length
targets from rollout pass-rates ("token calories"). Requires ground-truth answers.
**Base model.** R1-Distill-Qwen-1.5B only. *No CRISP overlap.*
**Results (Pass@1 / mean tokens):**
- MATH-500: 82.1→83.0, 5534→3061 tok (−44.7%).
- AIME24: 28.5→31.8, 16590→10578 tok (−36.2%).
- AIME25 / GPQA-D / MMLU: not evaluated.

### DiPO — arXiv:2601.21418 (Wan et al., 2026)
**Method.** Difficulty-aware RL that mitigates overthinking by estimating problem
difficulty and shaping per-problem length rewards. Requires ground-truth answers.
**Base models.** Qwen3-4B and R1-0528-Qwen3-8B (R1-distilled Qwen3-8B ≠ plain Qwen3-8B —
closest backbone to CRISP among all baselines).
**Results (acc / tokens):**
- MATH-500: Qwen3-4B 87.8→92.2 (3187→1355, −57%); R1-Qwen3-8B 81.6→83.4 (3895→1360).
- AIME25: Qwen3-4B 26.67→43.33 (7442→5950); R1-Qwen3-8B 16.67→30.00 (7633→6158).
- GPQA (Qwen3-4B; not verified as Diamond): 35.71→43.53 (5453→2769, −49%).
- MMLU (Qwen3-4B): 78.97→78.79 (1366→534, −61%).
- AIME24 not evaluated.

### Leash — arXiv:2512.21540 (Li et al., 2025)
**Method.** Adaptive length penalty + reward shaping (sigmoid) for efficient large
reasoning models. Requires ground-truth answers. Metric = Avg@32.
**Base models.** R1-Distill-Qwen-1.5B, Qwen3-4B-Thinking-2507. *No CRISP overlap.*
**Results (acc / tokens):**
- R1-1.5B (L_t=4k): AIME24 31.4→30.4 (16722→6779); AIME25 23.1→24.6 (16562→6126).
- Qwen3-4B (L_t=12k): AIME24 80.8→79.7 (19193→14211); AIME25 74.6→73.3 (21414→16700).
- MATH-500 absent; "GPQA" not Diamond; reports MMLU-**Pro**, not MMLU.

### AdaptThink — arXiv:2505.13417 (Zhang et al., 2025)
**Method.** RL that teaches a reasoning model *when to think* — choose no-think vs
think per problem — with a constrained objective favoring no-think when accuracy holds.
Requires ground-truth answers.
**Base models.** R1-Distill-Qwen-1.5B / 7B. *No CRISP overlap.*
**Results (acc / avg tokens):**
- MATH-500: 1.5B 80.6→82.0 (4887→1782, −63.5%); 7B 90.2→92.0 (3674→1875, ~−49%).
- AIME24: 1.5B 29.4→31.0 (12073→6679, −44.7%); 7B 53.5→55.6 (10306→8599, ~−17%).
- MMLU (OOD probe): 1.5B 35.7→42.2 (1724→1055); 7B 63.4→63.6 (1257→856).
- AIME25 / GPQA-D not evaluated.

### TRAAC — arXiv:2510.01581 (Think Right: Adaptive Attentive Compression)
**Method.** RL that mitigates under- & over-thinking via adaptive, attention-based
compression of the reasoning trace. Requires ground-truth answers.
**Base models.** Qwen3-4B, R1-Distill-Qwen-7B. *No CRISP overlap.*
**Results (acc / k-tokens):**
- GPQA-Diamond: Qwen3-4B 45.18→47.21 (7.6k→4.2k); R1-Qwen-7B 43.55→47.31 (7.1k→6.2k).
- "AIME" = combined 2022+2023+2024 (90 Q), **not** comparable to AIME24-only.
- MATH-500 / AIME25 / MMLU absent.

---

## SFT CoT-compression methods

### SEER — arXiv:2509.14093 (Huang et al., 2025)
**Method.** Self-optimizing framework: sample many solutions, keep the shortest correct
ones, fine-tune on them (adaptive CoT compression). Requires ground-truth answers.
**Overlap: NONE.** Software-engineering / code domain (MathQA-Python, HumanEval,
CodeXGLUE, GSM8K) on R1-Distill-Qwen-7B. Headline: 42.1% avg CoT-length reduction
(GSM8K: 90.1→90.5 acc, 1309→677 tok, 48.3% ↓). Cite in prose only.

### TokenSkip — arXiv:2502.12067 (Xia et al., 2025, EMNLP)
**Method.** Learns which CoT tokens are skippable and fine-tunes to produce controllable,
compressed chains at a target ratio. Requires ground-truth answers.
**Base models.** Llama-3.1-8B-Instruct, Qwen2.5. *No CRISP overlap.*
**Results (MATH-500 only, Llama-3.1-8B):** base 48.6% @ 502.6 tok; ratio-0.7 46.7% @ 349.1
(~31% ↓, −1.9 pts); ratio-0.9 47.8% @ 448.3 (~11% ↓, −0.8 pts). No AIME/GPQA/MMLU.

### DAP / LiteCoT — arXiv:2505.19716 (Wu et al., 2025)
**Method.** Difficulty-Aware Prompting distills a stronger model into short traces
(the LiteCoT dataset), then SFTs. Best *benchmark* coverage of any baseline. "GPQA" =
GPQA-Diamond (per their eval script); "MMLU" = MMLU-STEM.
**Base models.** Qwen2.5-Math / Qwen2.5-32B / 1.5B. *No CRISP overlap.*
**Results.** Liter models (method's numbers): Liter-7B AIME24 53.3, MATH500 93.8, GPQA-D
53.3; Liter-32B 76.7 / 96.6 / 63.6; Liter-1.5B 36.7 / 87.2 / 35.4.
DAP on Qwen2.5-Math-7B (vanilla→DAP): AIME24 13.3→23.3, AIME25 10.0→16.7, GPQA 27.3→29.8,
MMLU-STEM 68.8→64.4 (loses on MMLU). Compression reported dataset-level only: LiteCoT
~720 tok/sample vs competitors 4,095–10,500 (~6–15× fewer); no per-benchmark before→after.

### S3-CoT — arXiv:2602.01982 (Du et al., 2026)
**Method.** Self-Sampled Succinct CoT: model samples its own succinct reasoning and is
tuned toward brevity (steering + SFT). "MATH" = full MATH test set, **not** MATH-500.
**Base models.** Qwen2.5-7B, R1-Distill-7B, Llama3-8B, Qwen3-Think-4B. *No CRISP overlap.*
**Results (acc / tokens):**
- MATH (full): Qwen2.5-7B 72.67→70.50 (559→427); R1-7B 92.33→92.00 (4261→2833);
  Llama3-8B 47.67→50.33 (605→445).
- AIME24: Qwen2.5-7B 7.78→12.22 (997→801); R1-7B 51.11→51.11 (14061→12218);
  Qwen3-Think-4B 82.22→76.67 (21009→17284). ~17–21% token ↓ (math). No AIME25/GPQA/MMLU.

### V-Skip — arXiv:2601.13879
**Overlap: NONE.** Multimodal (VLM) CoT compression ("Dual-Path Anchoring"); benchmarks
MMMU (≠ MMLU), DocVQA, POPE on Qwen2-VL / Llama-3.2-Vision. ~2.9× speedup. Not usable.

### CtrlCoT — arXiv:2601.20467
**Method.** Controllable CoT compression (SFT) with tunable compression ratio.
**Base models.** Qwen2.5-Instruct 3B/7B/14B. *No CRISP overlap.*
**Results (MATH-500 only):** Qwen2.5-7B original 71.20 @ 574.6 tok → CtrlCoT (high) 58.00
@ 225.6 tok (CR 0.39); beats TokenSkip (50.40 @ 325.7). Qwen2.5-14B 66.60 @ 270.8 vs
TokenSkip 59.40 @ 346.0. No AIME/GPQA/MMLU.

---

## Training-free / inference-time methods

### Chain of Draft — arXiv:2502.18600 (Xu et al., 2025)
**Method.** Prompting trick: ask the model for minimal "drafts" instead of full CoT.
Training-free; no ground-truth needed.
**Overlap: NONE.** GSM8K, BIG-bench (date/sports/coin-flip) on GPT-4o & Claude 3.5.
Headline: GSM8K GPT-4o 95.4%/205 tok → 91.1%/44 tok (~79% ↓). Degrades on small open
models / zero-shot. Cite in prose only.

### TrimR — arXiv:2505.17155 (Lin et al., 2025)
**Method.** Verifier-based, training-free: a lightweight verifier truncates redundant
thinking at inference time. No ground-truth needed at train time.
**Base models.** QwQ-32B, R1-Distill-Qwen-32B, Pangu-R-38B. *No CRISP model overlap
(scale gap 32–38B vs 8–14B).*
**Results (baseline → TrimR; acc; token Δ):**
- MATH-500: QwQ 95.6→96.8 (−14%); R1-32B 90.4→92.4 (−40%); Pangu 95.6→94.4 (−19%).
- AIME24: QwQ 76.6→76.6 (−23%); R1-32B 60.0→63.3 (−36%); Pangu 78.3→76.6 (−19%).
- AIME25: QwQ 60.0→60.8 (−10%); R1-32B 47.9→56.3 (−38%); Pangu 57.5→57.5 (−21%).
- GPQA-D: QwQ 66.0→65.2 (−9%); R1-32B 45.4→58.6 (−46%); Pangu 59.1→60.1 (−8%).
- MMLU not reported. Accuracy roughly preserved or up.

### NoWait — arXiv:2506.08343 (Wang et al., 2025)  ★ only true head-to-head
**Method.** Training-free decoding intervention: suppress "Wait"/"Hmm"-type
self-doubt tokens during generation. No ground-truth needed.
**Base models.** **Qwen3-8B, Qwen3-14B** (exact CRISP overlap), plus R1-Distill-Qwen-7B.
**Results (acc / avg tokens; baseline → NoWait):**
- Qwen3-8B: AIME24 77.33→72.67 (−22.5% tok, −4.7 acc); AIME25 74.61→60.00 (−15% tok,
  −14.6 acc); GPQA-D 57.07→51.71 (−20% tok, −5.4 acc).
- Qwen3-14B: AIME24 78.67→73.33 (−23% tok, −5.3 acc); AIME25 78.00→61.33 (−18% tok,
  −16.7 acc); GPQA-D 59.59→54.75 (−16% tok, −4.8 acc).
- R1-Distill-Qwen-7B (analog, not Llama-8B): AIME24 34.67→26.67; AIME25 40.00→31.33
  (−40% tok); GPQA-D 49.10→40.91.
- **Contrast point for CRISP:** on hard sets at 8–14B, NoWait *loses* substantial accuracy
  (AIME25 −14 to −17 pts) while cutting tokens; CRISP compresses *and* improves accuracy.
- No MATH-500, no MMLU. GPQA numbers from appendix Table 6.

### FlowSteer — arXiv:2602.05539 (Li et al., 2026, TMLR)
**Method.** Inference-time steering toward concise reasoning via flow matching. Main
baseline compared against is SEAL.
**Base models.** R1-Distill-Qwen-1.5B/7B, QwQ-32B. *No CRISP overlap.*
**Results (Vanilla → FlowSteer; acc; token cut):**
- MATH-500: R1-1.5B 66.6→79.6 (−39%); R1-7B 87.0→90.2 (−24%); QwQ-32B 90.8→91.0 (−12%).
- AIME24: R1-1.5B 6.7→33.3 (−26%); R1-7B 50.0→53.3 (−15%); QwQ-32B 63.3→76.7 (−9%).
- Also GSM8K/AMC23/LiveCodeBench. No AIME25/GPQA/MMLU.

---

## On-policy self-distillation relatives (non-OPSD)

These are the closest *methodological* relatives to CRISP but report essentially no
overlap on CRISP's target benchmarks — they touch MMLU/MMLU-Pro only as retention probes.
Their value is the **efficiency-multiplier** framing.

### SDFT — arXiv:2601.19897 (Shenfeld et al., 2026)
**Method.** "Self-distillation enables continual learning": on-policy distillation with a
teacher given ground-truth/privileged context; interpreted as inverse RL; dramatically
reduces forgetting vs SFT.
**Base models.** Qwen2.5-7B-Instruct (primary), Qwen2.5 3B/7B/14B, Olmo-3-7B-Think.
**Overlap = MMLU only (retention probe):** base 71.7 → SDFT preserves (Sci-QA 70.7, Tool
71.5, Medical 71.5) vs SFT dropping to 64.6. New tasks: SciKnowEval, ToolAlpaca, medical.
Efficiency: ~2.5× FLOPs / ~4× wall-clock vs SFT; single on-policy generation per prompt.

### SDPO — arXiv:2601.20802 (Hübotter et al., 2026)
**Method.** "RL via self-distillation": conditions teacher on rich feedback for dense
credit assignment.
**Base models.** Qwen3-8B (default), Qwen3 0.6B–8B, Olmo3-7B, Qwen2.5.
**Overlap = MMLU-Pro holdout only** (≠ MMLU): base 62.5, GRPO 62.3, SDPO 62.9. Main tasks:
LiveCodeBench-v6, SciKnowEval, ToolAlpaca. Efficiency: matches GRPO in "4× fewer
generations" (48.8 vs 41.2 on LCBv6); responses "3–7× shorter"; "10× wall-clock" on Chem.

### OPCD — arXiv:2602.12275 (Ye et al., 2026)
**Method.** On-policy context distillation: distills system-prompt / in-context behaviors
into the weights.
**Base models.** Qwen3-1.7B/4B/8B, Qwen2.5-3B/7B, Llama-3.1/3.2.
**Overlap: NONE.** DAPO-Math-17K, Frozen Lake, Sokoban, IF-Eval, MedMCQA, safety sets.
Sample gains: Qwen3-8B math 75.0→79.7; Llama-3.2-3B medical 59.4→76.3. No token-reduction
ratios reported.

---

## Verification / provenance notes
- Numbers were extracted from arXiv abstract pages + ar5iv HTML full text. The SDPO/OPCD
  figures came partly from prose rather than clean tables — **verify those cells against
  the PDFs before publishing.**
- Flags to re-check before citing: S3-CoT "MATH" (full vs -500); DiPO/Leash "GPQA" (Diamond
  vs not); Leash "MMLU-Pro" vs MMLU; DAP/LiteCoT "GPQA"→Diamond mapping; TRAAC "AIME"
  (2022+23+24 composite, not AIME24-only); L1 "MATH" (full set).
- Reduction % marked "~" were recomputed from raw before→after token pairs where the paper
  reported lengths rather than a percentage.
