#!/usr/bin/env python3
"""Appendix G figures: divergence-direction comparison on Qwen3-8B (reverse KL, forward KL, JSD).

Two figures, matching the paper's clean sans-serif style:
  kl_comparison: validation accuracy vs. training step (MATH-500 and AIME 2024 panels),
  kl_tokens:     mean response length vs. training step (same panels).
Data pulled from W&B (Study A arms) into /tmp/kl_traj.json. Qwen3-14B is not included.
Colorblind- and grayscale-safe: distinct hue + line style + marker per divergence.
"""
import json
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

D = json.load(open("/tmp/kl_traj.json"))

# reverse KL solid, JSD dashed, forward KL dotted; distinct hues + markers.
STYLE = {
    "rkl": dict(label="Reverse KL (ours)", color="#3B7DB3", ls="-", marker="o"),
    "jsd": dict(label="JSD", color="#4DAF4A", ls="--", marker="s"),
    "fkl": dict(label="Forward KL", color="#C0392B", ls=":", marker="^"),
}
ORDER = ["rkl", "jsd", "fkl"]

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def style_ax(ax):
    ax.set_axisbelow(True)
    ax.grid(color="0.9", linewidth=0.6)
    ax.tick_params(length=3, colors="0.2")
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    for sp in ["left", "bottom"]:
        ax.spines[sp].set_color("0.4")


def make(metric_key, ylabel_a, ylabel_b, fname, title_a, title_b, xmax=None):
    fig, (axA, axB) = plt.subplots(1, 2, figsize=(9.2, 3.5))
    for arm in ORDER:
        d = D[arm]
        st = STYLE[arm]
        # optionally clip the series to steps <= xmax
        if xmax is not None:
            idx = [i for i, s in enumerate(d["step"]) if s <= xmax]
            xs = [d["step"][i] for i in idx]
            m = [d[f"m500_{metric_key}"][i] for i in idx]
            a = [d[f"a24_{metric_key}"][i] for i in idx]
        else:
            xs, m, a = d["step"], d[f"m500_{metric_key}"], d[f"a24_{metric_key}"]
        axA.plot(xs, m, lw=1.8, ms=4.5, **st)
        axB.plot(xs, a, lw=1.8, ms=4.5,
                 color=st["color"], ls=st["ls"], marker=st["marker"])
    axA.set_title(title_a, fontsize=12)
    axB.set_title(title_b, fontsize=12)
    for ax in (axA, axB):
        ax.set_xlabel("Training step")
        if xmax is not None:
            ax.set_xlim(-3, xmax + 3)
        style_ax(ax)
    axA.set_ylabel(ylabel_a)
    axB.set_ylabel(ylabel_b)
    axA.legend(frameon=False, fontsize=9.5, loc="best")
    fig.tight_layout()
    fig.savefig(fname, bbox_inches="tight")
    fig.savefig(fname.replace(".pdf", ".png"), dpi=200, bbox_inches="tight")
    print("wrote", fname)


# accuracy (%) vs step, cut to the first 100 steps (where forward KL collapses)
make("acc", "MATH-500 accuracy (%)", "AIME 2024 accuracy (%)",
     "kl_comparison.pdf", "MATH-500", "AIME 2024", xmax=100)
# response length (tokens) vs step, cut to the first 100 steps
make("tok", "MATH-500 length (tokens)", "AIME 2024 length (tokens)",
     "kl_tokens.pdf", "MATH-500", "AIME 2024", xmax=100)
