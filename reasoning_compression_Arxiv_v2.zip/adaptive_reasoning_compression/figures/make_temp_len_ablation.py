#!/usr/bin/env python3
"""Rollout-temperature and rollout-length ablations (Qwen3-8B, step 99, 30K budget).

Two separate figures, each with left = accuracy change (pp vs. base) and right = token reduction (%),
for MATH-500 and AIME 2024. Both are ordered sweeps; the point is robustness (flat curves) with the
default at the best operating point. Nature style, colorblind/grayscale-safe, no a/b labels.
Numbers are the step-99 values from the temperature and length ablation tables.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

STYLE = {
    "MATH-500": dict(color="#0072B2", marker="o", ls="-"),
    "AIME 2024": dict(color="#E69F00", marker="s", ls="--"),
}
plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def make(xs, xticklabels, dacc, red, xlabel, default_x, fname, logx=False):
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(9.0, 3.6))

    def style_ax(ax):
        if logx:
            ax.set_xscale("log")
        ax.set_xticks(xs)
        ax.set_xticklabels(xticklabels)
        ax.set_xlabel(xlabel)
        ax.grid(color="0.9", linewidth=0.6, zorder=0)
        ax.set_axisbelow(True)
        ax.tick_params(length=3, colors="0.2")
        for sp in ["top", "right"]:
            ax.spines[sp].set_visible(False)
        for sp in ["left", "bottom"]:
            ax.spines[sp].set_color("0.4")
        ax.axvline(default_x, color="0.7", lw=0.7, ls=":", zorder=1)

    for b in dacc:
        axL.plot(xs, dacc[b], lw=1.8, ms=5, label=b, **STYLE[b])
        axR.plot(xs, red[b], lw=1.8, ms=5, label=b, **STYLE[b])
    axL.axhline(0, color="0.6", lw=0.7, ls="--", zorder=1)
    axL.set_ylabel(r"$\Delta$Accuracy vs. base (pp)")
    axL.set_title("Accuracy change", fontsize=12)
    axR.set_ylabel("Token reduction (%)")
    axR.set_title("Compression", fontsize=12)
    for ax in (axL, axR):
        style_ax(ax)
    axL.legend(frameon=False, fontsize=9.5, loc="best")
    fig.tight_layout()
    fig.savefig(fname, bbox_inches="tight")
    fig.savefig(fname.replace(".pdf", ".png"), dpi=200, bbox_inches="tight")
    print("wrote", fname)


# ---- Rollout temperature ----
tau = [0.3, 0.6, 1.0, 1.5]
make(
    tau, [str(t) for t in tau],
    {"MATH-500": [-0.3, -0.7, 0.0, -0.6], "AIME 2024": [-4.9, -4.3, -1.6, -3.8]},
    {"MATH-500": [31.3, 33.3, 31.6, 30.8], "AIME 2024": [16.3, 17.4, 17.1, 16.0]},
    r"Rollout temperature $\tau$", 1.0, "temp_ablation.pdf",
)

# ---- Rollout length (log axis over 1k..30k) ----
L = [1, 4, 8, 30]
make(
    L, ["1k", "4k", "8k", "30k"],
    {"MATH-500": [0.1, -0.3, 0.0, -0.3], "AIME 2024": [-4.9, -3.2, -1.6, -6.5]},
    {"MATH-500": [29.8, 30.9, 31.6, 30.5], "AIME 2024": [13.7, 19.1, 17.1, 13.8]},
    "Max training rollout length (tokens)", 8, "len_ablation.pdf", logx=True,
)
