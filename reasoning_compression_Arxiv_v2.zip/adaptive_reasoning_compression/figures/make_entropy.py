#!/usr/bin/env python3
"""Student policy entropy over training (Qwen3-8B and Qwen3-14B, v2 teacher, M=50).

Mean full-vocab per-token entropy of the student's next-token distribution, averaged over
response tokens each training step. Entropy stays flat across the full run, showing CRISP compresses
reasoning without entropy collapse. Data: figures/entropy_traj.json (train/entropy from the
crisp-entropy-q8b / crisp-entropy-q14b reruns). Nature style, colorblind/grayscale-safe.
"""
import json
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

D = json.load(open("entropy_traj.json"))

C_8B = "#0072B2"
C_14B = "#E69F00"

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)

fig, ax = plt.subplots(figsize=(6.2, 3.6))

ax.plot(D["8b"]["steps"], D["8b"]["entropy"], color=C_8B, lw=1.6, label="Qwen3-8B")
ax.plot(D["14b"]["steps"], D["14b"]["entropy"], color=C_14B, lw=1.6, ls="--", label="Qwen3-14B")

# base-model entropy reference (step 0) as a faint guide
for series, col in (("8b", C_8B), ("14b", C_14B)):
    ax.axhline(D[series]["entropy"][0], color=col, lw=0.6, ls=":", alpha=0.5)

ax.set_xlabel("Training step")
ax.set_ylabel("Student entropy")
ax.set_ylim(0.0, 0.5)
ax.set_xlim(0, 99)
ax.grid(color="0.9", linewidth=0.6, zorder=0)
ax.set_axisbelow(True)
ax.tick_params(length=3, colors="0.2")
for sp in ["top", "right"]:
    ax.spines[sp].set_visible(False)
for sp in ["left", "bottom"]:
    ax.spines[sp].set_color("0.4")
ax.legend(frameon=False, fontsize=9.5, loc="lower left")

fig.tight_layout()
fig.savefig("entropy.pdf", bbox_inches="tight")
fig.savefig("entropy.png", dpi=200, bbox_inches="tight")
print("wrote entropy.pdf")
