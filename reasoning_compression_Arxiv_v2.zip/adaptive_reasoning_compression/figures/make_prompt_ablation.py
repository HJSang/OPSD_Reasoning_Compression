#!/usr/bin/env python3
"""Conciseness-instruction ablation: accuracy-compression trade-off scatter (Qwen3-8B, step 99).

Two panels (MATH-500, AIME 2024). x = token reduction (%), y = accuracy change vs. base (pp).
Upper-right is better (more compression, less accuracy loss). One labeled point per instruction v1-v5.
Nature style: sans-serif, flat markers, neutral a/b panel labels, colorblind/grayscale-safe.
Numbers are the step-99 values from the prompt-ablation table.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# instruction -> (MATH dAcc, MATH Red, AIME dAcc, AIME Red)
DATA = {
    "v1": (-0.1, 57.4, -2.7, 36.5),
    "v2": (0.0, 31.6, -1.6, 17.1),
    "v3": (-1.3, 62.9, -5.4, 35.2),
    "v4": (-2.9, 56.7, -3.2, 40.2),
    "v5": (-0.7, 54.7, -5.4, 32.3),
}
LABEL = {
    "v1": "v1 uniform",
    "v2": "v2 difficulty-aware",
    "v3": "v3 redundancy",
    "v4": "v4 expert",
    "v5": "v5 terse",
}
# Okabe-Ito colorblind-safe; v2 (default) emphasized.
COLOR = {"v1": "#E69F00", "v2": "#0072B2", "v3": "#009E73", "v4": "#CC79A7", "v5": "#555555"}
MARK = {"v1": "o", "v2": "D", "v3": "s", "v4": "^", "v5": "v"}

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)

fig, (axA, axB) = plt.subplots(1, 2, figsize=(9.0, 3.6))


def panel(ax, xi, yi, title):
    for k, v in DATA.items():
        x, y = v[xi], v[yi]
        ax.scatter(x, y, s=70, c=COLOR[k], marker=MARK[k], edgecolor="black",
                   linewidth=0.6, zorder=3, label=LABEL[k])
        ax.annotate(k, (x, y), textcoords="offset points", xytext=(6, 4),
                    fontsize=9, fontweight="bold", color=COLOR[k])
    ax.axhline(0, color="0.6", lw=0.7, ls="--", zorder=1)
    ax.set_xlabel("Token reduction (%)")
    ax.set_ylabel(r"$\Delta$Accuracy vs. base (pp)")
    ax.set_title(title, fontsize=12)
    ax.grid(color="0.9", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, colors="0.2")
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    for sp in ["left", "bottom"]:
        ax.spines[sp].set_color("0.4")


panel(axA, 1, 0, "MATH-500")
panel(axB, 3, 2, "AIME 2024")

# single shared legend below
handles, labels = axA.get_legend_handles_labels()
fig.legend(handles, labels, loc="lower center", ncol=5, frameon=False,
           bbox_to_anchor=(0.5, -0.04), fontsize=9.5, handletextpad=0.2, columnspacing=1.0)

fig.tight_layout(rect=(0, 0.06, 1, 1))
fig.savefig("prompt_ablation.pdf", bbox_inches="tight")
fig.savefig("prompt_ablation.png", dpi=200, bbox_inches="tight")
print("wrote prompt_ablation.pdf")
