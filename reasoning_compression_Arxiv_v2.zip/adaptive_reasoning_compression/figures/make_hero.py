#!/usr/bin/env python3
"""Hero figure for CRISP: Qwen3-14B reasoning length vs. accuracy across three benchmarks.

Nature-style: sans-serif, flat solid fills, thin bar edges, neutral bold panel labels (a, b) in the
top-left corner, no decorative arrows or hatching. Interpretation is left to the caption. Two solid
colours with clearly different hue and luminance (grey base, blue CRISP) remain distinguishable in
grayscale printing, reinforced by direct on-bar value labels.
Numbers are the Qwen3-14B rows of the main results table (30K-token budget, mean@8, v1 teacher).
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

BENCHES = ["MATH-500", "AIME 2024", "AIME 2025"]
SERIES = ["Qwen3-14B", "CRISP"]

TOKENS = {"Qwen3-14B": [4139, 13222, 15622], "CRISP": [1808, 8261, 10611]}
ACC = {"Qwen3-14B": [93.0, 75.0, 69.2], "CRISP": [96.3, 73.8, 62.9]}
RED = [56.3, 37.5, 32.1]  # token reduction vs. base (%)

# Grey base, blue CRISP: distinct hue and luminance, colorblind-safe, grayscale-safe.
COLORS = {"Qwen3-14B": "#BDBDBD", "CRISP": "#3B7DB3"}

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.direction": "out",
        "ytick.direction": "out",
    }
)

fig, (axL, axR) = plt.subplots(1, 2, figsize=(9.2, 3.5))
x = list(range(len(BENCHES)))
w = 0.36
offsets = {"Qwen3-14B": -w / 2, "CRISP": w / 2}


def draw(ax, data, fmt, pad):
    for s in SERIES:
        xs = [xi + offsets[s] for xi in x]
        bars = ax.bar(
            xs, data[s], width=w, color=COLORS[s], edgecolor="white", linewidth=0.5, zorder=3
        )
        for xi, b in zip(xs, bars):
            ax.text(
                xi, b.get_height() + pad, fmt(b.get_height()),
                ha="center", va="bottom", fontsize=8, color="0.15", zorder=4,
            )
    ax.set_xticks(x)
    ax.set_xticklabels(BENCHES)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="0.9", linewidth=0.6)
    ax.tick_params(length=3, colors="0.2")
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    for sp in ["left", "bottom"]:
        ax.spines[sp].set_color("0.4")


# ---- left: reasoning length ----
draw(axL, TOKENS, lambda v: f"{v/1000:.1f}k", pad=250)
axL.set_ylabel("Reasoning length (tokens)")
axL.set_ylim(0, 17000)
# reduction ratio above each CRISP bar (its token label sits just below)
for xi, r in zip(x, RED):
    axL.text(
        xi + offsets["CRISP"],
        TOKENS["CRISP"][xi] + 1150,
        f"$-${r:.0f}%",
        ha="center", va="bottom", fontsize=8.5, fontweight="bold",
        color=COLORS["CRISP"], zorder=4,
    )

# ---- right: accuracy ----
draw(axR, ACC, lambda v: f"{v:.1f}", pad=1.2)
axR.set_ylabel("Accuracy (mean@8, %)")
axR.set_ylim(0, 105)

handles = [Patch(facecolor=COLORS[s], edgecolor="none", label=s) for s in SERIES]
fig.legend(
    handles=handles, loc="upper center", ncol=2, frameon=False,
    bbox_to_anchor=(0.5, 1.02), fontsize=11, handlelength=1.3, columnspacing=1.8,
)

fig.tight_layout(rect=(0, 0, 1, 0.93))
out = "hero_qwen3_14b_30k.pdf"
fig.savefig(out, bbox_inches="tight")
fig.savefig(out.replace(".pdf", ".png"), dpi=200, bbox_inches="tight")
print("wrote", out)
