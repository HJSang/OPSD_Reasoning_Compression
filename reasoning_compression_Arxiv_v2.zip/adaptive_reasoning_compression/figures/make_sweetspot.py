#!/usr/bin/env python3
"""Compression sweet spot over a full training epoch (Qwen3-8B, v2 teacher, M=50).

Left: accuracy vs. training step (MATH-500, AIME 2024). Right: MATH-500 compression factor
(base length / current length) vs. step. Accuracy stays flat while compression climbs to ~2x,
then declines as compression is pushed further. A shaded band marks the sweet-spot region.
Data: full 1-epoch a_rkl trajectory (/tmp/v2_full_epoch.json). Nature style, colorblind/grayscale-safe.
"""
import json
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

D = json.load(open("/tmp/v2_full_epoch.json"))
step = D["step"]
fac = [1.0 / (1.0 - r / 100.0) for r in D["m500_red"]]  # MATH-500 compression factor

C_MATH = "#0072B2"
C_AIME = "#E69F00"
C_FAC = "#009E73"

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)

fig, (axL, axR) = plt.subplots(1, 2, figsize=(9.2, 3.6))

# Accuracy is preserved from the start up to ~2x compression (reached near step 220,
# where AIME 2024 begins to erode). That preserved region is the sweet spot; beyond it,
# extra compression is small and accuracy drops.
SWEET = (0, 220)
CKPT = 99  # the step-99 checkpoint used throughout the paper (~1.45x compression)


def style_ax(ax):
    ax.grid(color="0.9", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, colors="0.2")
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    for sp in ["left", "bottom"]:
        ax.spines[sp].set_color("0.4")
    ax.set_xlabel("Training step")
    ax.axvspan(*SWEET, color="0.85", alpha=0.5, zorder=0)
    ax.axvline(CKPT, color="0.35", lw=0.9, ls="--", zorder=2)


# left: accuracy
axL.plot(step, D["m500_acc"], color=C_MATH, marker="o", ms=4, lw=1.6, label="MATH-500")
axL.plot(step, D["a24_acc"], color=C_AIME, marker="s", ms=4, lw=1.6, ls="--", label="AIME 2024")
axL.set_ylabel("Accuracy (mean@8, %)")
axL.set_title("Accuracy", fontsize=12)
axL.set_ylim(50, 100)
style_ax(axL)
axL.legend(frameon=False, fontsize=9.5, loc="lower left")

# right: compression factor
axR.plot(step, fac, color=C_FAC, marker="D", ms=4, lw=1.6)
axR.axhline(2.0, color="0.5", lw=0.8, ls=":")
axR.text(step[-1], 2.03, r"$2\times$", ha="right", va="bottom", fontsize=9, color="0.4")
axR.set_ylabel(r"MATH-500 compression factor ($\times$)")
axR.set_title("Compression", fontsize=12)
style_ax(axR)

# annotate the sweet-spot band (top) and the step-99 checkpoint (rotated along its line).
# Left panel: place label in the clear gap between the MATH-500 and AIME curves;
# right panel: place it low, where the curve has not yet risen.
CKPT_FRAC = {id(axL): 0.55, id(axR): 0.30}
for ax in (axL, axR):
    y0, y1 = ax.get_ylim()
    ax.text(sum(SWEET) / 2, y1, "sweet spot (accuracy preserved)", ha="center",
            va="top", fontsize=8.5, color="0.4")
    ax.text(CKPT + 5, y0 + CKPT_FRAC[id(ax)] * (y1 - y0), "step 99 (this paper)",
            ha="left", va="center", rotation=90, fontsize=7.5, color="0.35")

fig.tight_layout()
fig.savefig("sweetspot.pdf", bbox_inches="tight")
fig.savefig("sweetspot.png", dpi=200, bbox_inches="tight")
print("wrote sweetspot.pdf")
