#!/usr/bin/env python3
"""Teacher update-interval (M) ablation (Qwen3-8B, step 99, 30K budget).

Left: accuracy vs. M. Right: token reduction vs. M. Two benchmarks (MATH-500, AIME 2024).
M is an ordered sweep; plotted on a log x-axis. Shows the compression-stability trade-off:
M=1 collapses, larger M is stable but compresses less.
Nature style: sans-serif, colorblind/grayscale-safe, no a/b labels (referenced as left/right).
Numbers are the step-99 values from the M-ablation table.
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

M = [1, 10, 30, 50, 100]
ACC = {"MATH-500": [60.8, 92.4, 95.7, 95.7, 95.1], "AIME 2024": [6.7, 49.6, 67.9, 75.0, 77.5]}
RED = {"MATH-500": [-18.7, 64.1, 52.4, 31.6, 18.0], "AIME 2024": [1.0, 45.8, 28.8, 17.1, 10.6]}

STYLE = {
    "MATH-500": dict(color="#0072B2", marker="o", ls="-"),
    "AIME 2024": dict(color="#E69F00", marker="s", ls="--"),
}

plt.rcParams.update(
    {
        "font.size": 11,
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
        "axes.linewidth": 0.6,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)

fig, (axL, axR) = plt.subplots(1, 2, figsize=(9.0, 3.6))


def style_ax(ax):
    ax.set_xscale("log")
    ax.set_xticks(M)
    ax.set_xticklabels([str(m) for m in M])
    ax.set_xlabel("Teacher update interval $M$")
    ax.grid(color="0.9", linewidth=0.6, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=3, colors="0.2")
    for sp in ["top", "right"]:
        ax.spines[sp].set_visible(False)
    for sp in ["left", "bottom"]:
        ax.spines[sp].set_color("0.4")


for b in ACC:
    axL.plot(M, ACC[b], lw=1.8, ms=5, label=b, **STYLE[b])
    axR.plot(M, RED[b], lw=1.8, ms=5, label=b, **STYLE[b])

# mark the default M=50
for ax, series in [(axL, ACC), (axR, RED)]:
    ax.axvline(50, color="0.7", lw=0.7, ls=":", zorder=1)
axL.annotate("default", (50, 40), fontsize=8, color="0.4", rotation=90, va="center", ha="right")

axL.set_ylabel("Accuracy (mean@8, %)")
axL.set_title("Accuracy", fontsize=12)
axL.set_ylim(0, 100)
axR.axhline(0, color="0.6", lw=0.7, ls="--", zorder=1)
axR.set_ylabel("Token reduction (%)")
axR.set_title("Compression", fontsize=12)
for ax in (axL, axR):
    style_ax(ax)
axL.legend(frameon=False, fontsize=9.5, loc="lower right")

fig.tight_layout()
fig.savefig("m_ablation.pdf", bbox_inches="tight")
fig.savefig("m_ablation.png", dpi=200, bbox_inches="tight")
print("wrote m_ablation.pdf")
