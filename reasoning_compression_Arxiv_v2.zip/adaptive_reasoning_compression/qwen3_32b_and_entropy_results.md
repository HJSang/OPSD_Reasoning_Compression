# Qwen3-32B step-99 results + entropy-preservation trajectories

Collected 2026-07-03. All accuracies are mean@8 under a 30K-token budget, scored with the CRISP
dual-path grader (`Answer:` line **or** `\boxed{}`, math-verified). Lengths are average response
tokens. Two conciseness instructions: **v1** = uniform concise prompt; **v2** = difficulty-aware
concise prompt (default).

Runs:
- 32B v1 training: `crisp-ablE-v1-32b-dull-pint` (wandb `a3t4zc79`, project `slime-math-mixture`)
- 32B v2 training: `crisp-main-v2-32b-mere-clock` (wandb `pl4m8ol4`, project `slime-math-mixture`)
- 32B v1 step-99 eval: `crisp-step99-eval-v1-qwen3-32b` (wandb `vkwhffgt`, project `slime-rl-leviathan`)
- 32B v2 step-99 eval: `crisp-step99-eval-v2-qwen3-32b` (wandb `i8590ruj`, project `slime-rl-leviathan`)
- 8B v2 entropy rerun: `crisp-entropy-q8b` (wandb `4csp2iqn`, project `slime-math-mixture`)
- 14B v2 entropy rerun: `crisp-entropy-q14b` (wandb `jpev3ejh`, project `slime-math-mixture`)

Both 32B training runs were stopped at step 99 (HF export `hf/iter_0000099` verified: 17/17
safetensors + config + index) and evaluated on the 5 standard benchmarks. Both entropy reruns
completed all 100 steps with the new `train/entropy` metric logged every step.

---

## 1. Qwen3-32B step-99: full 5-benchmark eval

Accuracy (Acc, mean@8, %) and average response length (Len, tokens).

| Benchmark      | v1 Acc | v1 Len | v2 Acc | v2 Len |
|----------------|-------:|-------:|-------:|-------:|
| MATH-500       |  94.3  |  1,971 |  96.0  |  2,791 |
| AIME 2024      |  72.9  |  8,637 |  80.4  | 10,024 |
| AIME 2025      |  61.7  | 11,159 |  68.3  | 12,328 |
| GPQA-Diamond   |  66.1  |  4,932 |  66.4  |  5,796 |
| MMLU           |  86.5  |    847 |  86.2  |  1,080 |

### Base-model reference (partial)

A clean 5-benchmark base-model eval for Qwen3-32B has **not** yet been run. The only base numbers
available are the step-0 eval logged during training (math benchmarks only, mean@8, 30K budget):

| Benchmark  | Base Acc | Base Len |
|------------|---------:|---------:|
| MATH-500   |    ~95.6 |   ~3,988 |
| AIME 2024  |    ~80.5 |  ~12,300 |

(step-0 values agreed across both training runs: v1 95.6% / 3,988 & 80.8% / 12,302; v2 95.5% /
4,018 & 78.3% / 12,314. GPQA-Diamond, AIME 2025, and MMLU base numbers are pending a dedicated base
eval.)

### Read

- Both variants preserve MATH-500 (~94–96%) and out-of-domain accuracy (GPQA-D ~66%, MMLU ~86%)
  while shortening reasoning.
- **v2 protects hard problems far better than v1**: AIME 2024 80.4% vs 72.9%; AIME 2025 68.3% vs
  61.7%. This matches the difficulty-aware guardrail seen at 8B/14B.
- **v1 compresses harder**: shorter responses on every benchmark (e.g. MATH-500 1,971 vs 2,791 tok).
- Relative to the ~3,988-tok / ~12,300-tok math base, v1 cuts MATH-500 length ~51% and AIME 2024
  ~30%; v2 cuts ~30% and ~19%. Same scale-invariant pattern as the smaller models.

---

## 2. Entropy preservation during training (mean per-token student entropy)

The `train/entropy` metric is the mean full-vocab Shannon entropy of the student's next-token
distribution over response tokens, averaged per rollout step (computed in the in-engine OPSD loss
via the tensor-parallel entropy primitive; logging-only, grad-free).

Entropy stays essentially flat across the full 100-step run for both models — self-distillation
compresses reasoning **without** collapsing the policy's entropy.

| Run           | step 0 | step 99 |   min |   max | mean (0–99) |
|---------------|-------:|--------:|------:|------:|------------:|
| 8B v2 entropy | 0.3265 |  0.2879 | ~0.27 | ~0.34 |      ~0.30  |
| 14B v2 entropy| 0.3294 |  0.3179 | ~0.28 | ~0.34 |      ~0.32  |

### Sampled trajectory (every ~8 steps)

| step | 8B v2 entropy | 14B v2 entropy |
|-----:|--------------:|---------------:|
|    0 |        0.3265 |         0.3294 |
|    8 |        0.3182 |         0.3310 |
|   16 |        0.2924 |         0.3119 |
|   24 |        0.2820 |         0.3001 |
|   32 |        0.2954 |         0.3161 |
|   40 |        0.3057 |         0.3230 |
|   48 |        0.3133 |         0.3224 |
|   56 |        0.3340 |         0.3372 |
|   64 |        0.3009 |         0.3378 |
|   72 |        0.2877 |         0.3146 |
|   80 |        0.3194 |         0.3379 |
|   88 |        0.2666 |         0.2815 |
|   96 |        0.3019 |         0.3323 |
|   99 |        0.2879 |         0.3179 |

Full 100-step arrays are in `figures/entropy_traj.json` (if exported).

---

## Notes / caveats

- The two 32B training runs show wandb state `crashed` — this is only because their pods were
  deleted mid-run when training was stopped at step 99; the step-99 checkpoints were saved and
  verified **before** stopping, so the eval is valid.
- Only **v2** entropy was collected for the reruns. A **v1** entropy run for Qwen3-8B is not yet
  available (the original v1 8B ablation run predates the `train/entropy` logging change); a rerun
  is needed to get the v1 entropy curve.
- The 32B base-model 5-benchmark eval is still outstanding (needed for reduction-% / accuracy-delta
  columns comparable to the 8B/14B/DeepSeek main table).
