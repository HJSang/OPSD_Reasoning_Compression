# Adaptive Reasoning Compression by On-Policy Self-Distillation

**Working Title:** Adaptive Reasoning Compression by On-Policy Self-Distillation

**Status:** Initial ideation

---

## 1. Core Idea

Use **on-policy self-distillation** to compress reasoning traces without requiring ground-truth answers, external teachers, or hard token budgets. The model serves as both teacher and student:

- **Teacher:** $\pi_\theta(\cdot \mid x, c)$ — same model conditioned on a conciseness instruction $c$
- **Student:** $\pi_\theta(\cdot \mid x)$ — same model without the instruction

The conciseness instruction $c$ is a static prompt like:

> "Solve the following math problem concisely and correctly. Be direct — avoid unnecessary elaboration, redundant steps, or restating the problem. Focus only on the key reasoning steps needed to reach the answer."

Training minimizes per-token reverse KL divergence on **student-generated rollouts**:

$$\mathcal{L}(\theta) = \mathbb{E}_{x \sim \mathcal{D}, \; y \sim \pi_\theta(\cdot \mid x)} \left[ \sum_{t=1}^{|y|} D_{\text{KL}} \left( \pi_\theta(\cdot \mid x, y_{<t}) \;\|\; \text{sg}(\pi_\theta(\cdot \mid x, c, y_{<t})) \right) \right]$$

where $\text{sg}$ is stop-gradient on the teacher.

**Key insight:** The conciseness-conditioned teacher naturally produces a distribution that favors shorter, more direct reasoning paths. By distilling this on the student's own rollouts, the student learns to internalize concise reasoning behavior — compressing its own reasoning without needing any ground-truth answers or external supervision.

---

## 2. Advantages Over Existing Methods

| Property | Ours | RL-based (DLER, Leash, DiPO) | SFT-based (SEER, DART, V-Skip) | Training-free (TrimR, NoWait) |
|---|---|---|---|---|
| **On-policy** | Yes | Yes | No (off-policy SFT) | N/A |
| **No knowledge forgetting** | Yes (on-policy prevents catastrophic forgetting per SDFT) | Partial (KL penalty to ref) | No (SFT exposure bias) | Yes (no training) |
| **No correct answer needed** | Yes | No (needs ground-truth for reward) | Most need GT for filtering | No (inference-only) |
| **No hard budget** | Yes (naturally adaptive) | Mostly soft penalties | Some use hard ratios | Some use hard thresholds |
| **Difficulty-adaptive** | Yes (teacher adjusts naturally) | Requires explicit modeling | Requires explicit modeling | No |
| **Data efficient** | Yes (per on-policy distillation literature) | No (many rollouts per prompt) | Yes (one-pass SFT) | N/A |
| **Dense learning signal** | Yes (token-level KL) | No (sparse outcome reward) | Yes (token-level CE) | N/A |

### Detailed advantage explanations:

**1. On-policy → No knowledge forgetting.** SDFT (Shenfeld et al., 2026) demonstrates that on-policy self-distillation substantially reduces catastrophic forgetting compared to off-policy SFT. Our method inherits this property. The student is trained on its own generation distribution, so it never encounters out-of-distribution states that could cause forgetting.

**2. No need for correct answers or solutions.** Unlike 79% of existing reasoning compression methods (see analysis table), our method requires NO ground-truth answers. The teacher signal comes from the model's own ability to follow the conciseness instruction via in-context learning. This makes it applicable to:
- Domains without verifiable answers (open-ended reasoning, writing, analysis)
- Settings where answer checking is expensive or unavailable
- Continual self-improvement without labeled data

**3. No hard reasoning budget — adaptive by difficulty.** When the model encounters a hard problem, the teacher (conditioned on "be concise") still needs many reasoning steps to solve it, so the KL signal naturally preserves those steps. For easy problems, the teacher produces a much shorter trace, providing stronger compression signal. This difficulty-adaptive behavior emerges naturally from the teacher's in-context understanding, without any explicit difficulty estimation mechanism.

**4. Data efficient.** On-policy distillation has been shown to be 4-8x more token-efficient than GRPO (OPSD, Zhao et al. 2026). We inherit this: each student rollout produces a dense token-level learning signal, vs. RL which only gets a binary reward per rollout.

**5. Theoretical justification needed.** (See Section 4 below.)

---

## 3. Method Details

### 3.1 Problem Formulation

Given a base reasoning model $\pi_\theta$ and a conciseness instruction $c$, we want to find $\theta^*$ such that:

$$\theta^* = \arg\min_\theta \; \mathbb{E}_{x \sim \mathcal{D}} \left[ D_{\text{KL}}(\pi_\theta(\cdot \mid x) \;\|\; \pi_{\bar{\theta}}(\cdot \mid x, c)) \right]$$

where $\bar{\theta}$ is either:
- **Frozen:** The initial model parameters (simplest)
- **EMA:** Exponential moving average of $\theta$ (per SDFT)
- **Concurrent:** Same $\theta$ with stop-gradient (per OPSD)

### 3.2 Training Algorithm

```
Algorithm: On-Policy Self-Distillation for Reasoning Compression (OPSDC)

Input: Model π_θ, dataset D = {x_i}, conciseness instruction c
Hyperparameters: learning rate η, batch size B, EMA decay α

for each training step:
    1. Sample batch {x_1, ..., x_B} from D
    2. For each x_i:
       a. Generate student rollout: y_i ~ π_θ(· | x_i)       [no instruction]
       b. Compute teacher logits: π_θ̄(· | x_i, c, y_{i,<t})  [with instruction, stop-grad]
       c. Compute student logits: π_θ(· | x_i, y_{i,<t})
       d. Compute token-level reverse KL: L_i = Σ_t KL(student_t || teacher_t)
    3. Update: θ ← θ - η · ∇_θ (1/B) Σ_i L_i
    4. Update EMA: θ̄ ← α·θ̄ + (1-α)·θ
```

### 3.3 Conciseness Instructions (Variants)

**Static instruction (primary):**
```
"Solve the following math problem concisely and correctly. Be direct — avoid
unnecessary elaboration, redundant steps, or restating the problem. Focus only
on the key reasoning steps needed to reach the answer."
```

**Soft budget instruction (experimental):**
```
"Solve the following math problem correctly using {percent_reduce}% fewer tokens
than you normally would. Be more concise — cut unnecessary elaboration, redundant
steps, and verbose explanations while preserving correctness."
```

The soft budget variant is interesting because:
- It gives a controllable compression knob at training time
- We can curriculum over percent_reduce: start gentle (20%), increase (50%, 70%)
- At inference, the model has internalized varying levels of compression
- Research question: does this outperform the static instruction?

### 3.4 Why Does the Teacher Produce Shorter Reasoning?

The conciseness instruction works because:
1. **In-context following:** Modern reasoning LLMs can follow instructions to be more concise
2. **The teacher doesn't need to be perfect:** Even imperfect compression by the teacher provides a useful signal — the student only needs to move in the direction of more concise reasoning
3. **Progressive compression:** Over training, the student becomes more concise. If the teacher is EMA/concurrent, it too becomes more concise, creating a self-reinforcing compression effect
4. **Natural difficulty adaptation:** The teacher will naturally use more tokens for harder problems even when asked to be concise, preserving necessary reasoning steps

---

## 4. Theory

### 4.1 Required Theoretical Results

**Theorem 1 (Compression without accuracy loss).** Under mild assumptions, minimizing the reverse KL between student and conciseness-conditioned teacher preserves the accuracy of the original model while reducing expected response length.

*Proof sketch:*
- The conciseness-conditioned teacher $\pi(\cdot|x,c)$ has similar accuracy to $\pi(\cdot|x)$ (by instruction following)
- But the teacher's distribution concentrates on shorter, more direct reasoning paths
- Reverse KL is mode-seeking: the student learns the *high-probability* modes of the teacher
- High-probability modes under the concise teacher are the essential reasoning steps
- Result: student preserves accuracy while reducing length

**Theorem 2 (On-policy self-distillation as implicit reward maximization).** OPSDC is equivalent to maximizing an implicit reward function that combines task performance with conciseness preference, without requiring explicit reward engineering.

*Connection to SDFT's IRL interpretation:*
- SDFT shows self-distillation is equivalent to trust-region RL with an implicit reward
- The implicit reward = log-likelihood ratio: $r(y_t, x) = \log \pi(\cdot|x,c,y_{<t}) - \log \pi(\cdot|x,y_{<t})$
- This reward is positive when the teacher (concise) assigns higher probability than the student (verbose) — i.e., it rewards concise reasoning tokens
- This provides theoretical grounding for why compression happens without explicit length penalties

**Theorem 3 (No catastrophic forgetting bound).** The on-policy training objective ensures that the updated policy stays close to the original policy in total variation distance, bounding catastrophic forgetting.

*From SDFT/OPSD literature:*
- On-policy sampling ensures the student only updates on states it visits
- The reverse KL objective is mode-seeking, not mode-covering — it doesn't force the student to cover modes it wouldn't naturally visit
- Combined with EMA teacher, this provides stability guarantees

### 4.2 Difficulty-Adaptivity Analysis

**Proposition (Natural difficulty adaptation).** Let $\Delta(x) = \mathbb{E}[L_{\text{teacher}}(x)] - \mathbb{E}[L_{\text{student}}(x)]$ be the expected length reduction for problem $x$. Then $|\Delta(x)|$ is inversely correlated with problem difficulty: easy problems see more compression, hard problems see less.

*Intuition:* For easy problems, the concise teacher can dramatically shorten reasoning (e.g., skip verification steps). For hard problems, even the concise teacher needs most reasoning steps, so $\Delta(x) \approx 0$. This means the KL signal naturally adapts — easy problems get strong compression signal, hard problems get weak compression signal.

---

## 5. Experimental Plan

### 5.1 Datasets and Models

**Base models:**
- DeepSeek-R1-Distill-Qwen-1.5B / 7B / 14B
- Qwen3-4B / 8B

**Training data:**
- MATH (12.5K problems, no answers needed for training)
- GSM8K (7.5K problems)
- OpenMathInstruct (subset)

**Evaluation benchmarks:**
- In-domain: MATH-500, GSM8K
- Out-of-domain: AIME 2024, AMC 2023, GPQA-Diamond, Olympiad Bench, MMLU-Pro, BBEH

### 5.2 Baselines

From the 42-paper analysis, select representative methods:
- **RL-based:** Leash, DiPO, DLER, LASER, TRAAC
- **SFT-based:** SEER, DART, V-Skip, S3-CoT, DAP/LiteCoT
- **Training-free:** TrimR, NoWait, Chain of Draft
- **Self-distillation (non-compression):** OPSD, SDFT (to show compression is our addition)

### 5.3 Key Experiments

**Experiment A: Main results — Does it work?**
- Train OPSDC on MATH, evaluate on MATH-500 and GSM8K
- Metrics: Accuracy (pass@1), Average token length, Compression ratio, AE Score
- Compare against all baselines

**Experiment B: Out-of-domain generalization**
- Train on MATH only
- Evaluate on AIME, AMC, GPQA, Olympiad, BBEH
- Key question: Does compression generalize beyond the training domain?
- This is a differentiator vs. SFT-based methods

**Experiment C: Soft budget instruction**
- Compare static instruction vs. "use X% fewer tokens"
- Vary X = {20, 30, 40, 50, 60, 70}
- Measure: Is there a sweet spot? Does curriculum training help?
- Generate accuracy-vs-compression Pareto curves

**Experiment D: No answer required — ablation**
- Show that our method works identically with or without ground-truth filtering
- Compare: (1) OPSDC (no GT), (2) OPSDC + filter correct rollouts, (3) RL baseline (requires GT)
- Demonstrate that not needing GT doesn't hurt performance

**Experiment E: Catastrophic forgetting**
- Sequential training: First compress math, then compress code
- Measure: Does math performance degrade after code compression training?
- Compare against SFT-based compression methods (should show forgetting)

**Experiment F: Difficulty-adaptive analysis**
- Bucket problems by difficulty (easy/medium/hard based on base model pass rate)
- Measure compression ratio per difficulty bucket
- Show: easy problems get compressed more, hard problems preserved
- Compare against methods with explicit difficulty modeling (DiPO, TRAAC, DIET)

**Experiment G: Scaling analysis**
- Run across model sizes: 1.5B, 4B, 7B, 8B, 14B
- Question: At what scale does self-distillation become effective?
- OPSD reports minimum capacity needed; we should check this for compression

**Experiment H: Training efficiency**
- Compare wall-clock time and GPU hours vs. RL baselines
- OPSD reports 4-8x token efficiency over GRPO; we should expect similar

### 5.4 Ablation Studies

- **Teacher parameterization:** Frozen vs. EMA vs. stop-grad concurrent
- **Instruction variants:** Static vs. soft budget vs. curriculum
- **KL direction:** Reverse KL vs. forward KL vs. JSD
- **Number of rollouts per prompt:** 1 vs. 2 vs. 4
- **Training data size:** How few problems needed?

---

## 6. Related Work Positioning

### 6.1 Papers We Build On (Methodology)
- **OPSD** (Zhao et al., 2026) — On-policy self-distillation framework; teacher conditioned on answer
- **SDPO** (Hübotter et al., 2026) — RL via self-distillation with rich feedback
- **SDFT** (Shenfeld et al., 2026) — Self-distillation for continual learning; no forgetting
- **OPCD** (Ye et al., 2026) — On-policy context distillation; system prompt internalization

### 6.2 Papers We Compare Against (Compression)
From the 42-paper survey (see paper pool):
- RL with length penalty: DLER, Leash, DiPO, JET, ORION, LASER, TRAAC, DIET, Art of Efficient
- SFT on compressed data: SEER, DART, V-Skip, CtrlCoT, S3-CoT, DAP/LiteCoT, Extra-CoT
- Training-free: TrimR, NoWait, STU-PID, FlowSteer, Chain of Draft

### 6.3 Our Unique Positioning
We are the first to combine on-policy self-distillation with reasoning compression. The closest work:
- **OPCD** does system prompt distillation but not reasoning compression
- **S3-CoT** does concise reasoning via activation steering but not on-policy self-distillation
- **FlowSteer** steers toward concise representations at inference but is training-free
- **RL-based methods** (DiPO, TRAAC, DIET) optimize length in reward but need ground-truth

**Our novelty:** Using conciseness instruction as the "context" in on-policy context distillation to achieve reasoning compression that is answer-free, on-policy, difficulty-adaptive, and theoretically grounded.

---

## 7. Paper Outline (Preliminary)

1. **Introduction**
   - Reasoning models are powerful but verbose (cite: CoT compression survey)
   - Existing methods need ground-truth answers (79%) or hard budgets (29%)
   - We propose OPSDC: on-policy self-distillation for reasoning compression
   - No answers needed, no hard budgets, naturally difficulty-adaptive, no forgetting

2. **Related Work**
   - Reasoning compression (summarize 42-paper landscape with our 4-question table)
   - On-policy self-distillation (OPSD, SDPO, SDFT, OPCD)
   - Positioning: what's new

3. **Method**
   - Problem formulation
   - Conciseness instruction design
   - Training algorithm (OPSDC)
   - Soft budget variant

4. **Theoretical Analysis**
   - Theorem 1: Compression without accuracy loss
   - Theorem 2: Implicit reward interpretation
   - Theorem 3: Forgetting bound
   - Proposition: Difficulty-adaptivity

5. **Experiments**
   - Main results (A)
   - Out-of-domain generalization (B)
   - Soft budget experiments (C)
   - No-answer ablation (D)
   - Catastrophic forgetting (E)
   - Difficulty-adaptive analysis (F)
   - Scaling (G)
   - Efficiency (H)

6. **Conclusion**

---

## 8. Key References (Already in Paper Pool)

### Self-Distillation Methods
| Paper | File | Key Mechanism |
|---|---|---|
| Self-Distilled Reasoner (OPSD) | `MLAlgorithm/Self-Distilled_Reasoner_On-Policy_Self-Distillation_for_Large_Language_Models.md` | Teacher conditioned on answer y* |
| RL via Self-Distillation (SDPO) | `MLAlgorithm/Reinforcement_Learning_via_Self-Distillation.md` | Teacher conditioned on rich feedback |
| Self-Distillation Continual Learning (SDFT) | `MLAlgorithm/Self-Distillation_Enables_Continual_Learning.md` | Teacher conditioned on demonstration |
| On-Policy Context Distillation (OPCD) | `MLAlgorithm/On-Policy_Context_Distillation_for_Language_Models.md` | Teacher conditioned on system prompt |

### Reasoning Compression Methods (42 papers — see survey table)
All papers in `MLAlgorithm/` directory. Key representatives:
- DiPO, TRAAC, DIET (RL + difficulty-aware)
- SEER, DART, DAP/LiteCoT (SFT-based)
- TrimR, NoWait (training-free)

---

## 9. Open Questions

1. **Does the conciseness instruction actually make the teacher produce shorter reasoning?** Need to verify empirically that $\mathbb{E}[L(\pi(\cdot|x,c))] < \mathbb{E}[L(\pi(\cdot|x))]$ and that accuracy is preserved.

2. **Progressive compression collapse?** If using EMA/concurrent teacher, the student becomes more concise, making the teacher more concise, making the student even more concise... Could this collapse to trivially short outputs? Need stability analysis.

3. **Is reverse KL the right divergence?** Forward KL would be mode-covering (might preserve verbose modes). Reverse KL is mode-seeking (focuses on concise modes). JSD is a compromise. Need ablation.

4. **How does this interact with thinking tokens (`<think>`, `</think>`)?** The instruction might affect the think-answer boundary differently. Need to check if compression happens inside the thinking block or by reducing the thinking block itself.

5. **Instruction sensitivity:** How sensitive is the method to the exact wording of the conciseness instruction? Need to test multiple phrasings.
